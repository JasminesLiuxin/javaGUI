package start;

import javax.swing.UIManager;

import list.ViewList;
import view.View;

public class start {

	public static void main(String[] args) {
		if (ViewList.getList().size()==0) {
			
		 View v=new View();
		 
		 ViewList.add(v);
		 
			try
	    	{
	    		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	        }catch(Exception exception){
	        	exception.printStackTrace();
	        }
		 
		}
		
		System.out.println("����");
	}
}
